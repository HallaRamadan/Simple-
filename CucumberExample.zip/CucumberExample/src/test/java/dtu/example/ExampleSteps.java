package dtu.example;

import static org.junit.Assert.assertEquals;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/*
	Replace the class with your own step definition
   	classes.
 */
public class ExampleSteps {

	@Given("that the test is setup")
	public void thatTheTestIsSetup() {
		// Write code here that turns the phrase above into concrete actions
	}

	@When("an action is performed")
	public void anActionIsPerformed() {
		// Write code here that turns the phrase above into concrete actions
	}

	@Then("this condition is true")
	public void thisConditionIsTrue() {
		// Write code here that turns the phrase above into concrete actions
	}
}
